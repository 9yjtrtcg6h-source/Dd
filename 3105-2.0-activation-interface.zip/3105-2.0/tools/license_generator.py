#!/usr/bin/env python3
"""Issue signed license keys for the owner's modified 3105-custom build.
Requires: python3 -m pip install cryptography
"""
import argparse, base64, json, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from cryptography.hazmat.primitives import serialization

PRODUCT = "3105-custom"

def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")

def main():
    parser = argparse.ArgumentParser(description="Generate a signed 3105 custom-build license")
    parser.add_argument("--private-key", required=True, help="Path to your Ed25519 private PEM key")
    parser.add_argument("--duration", choices=["1d", "7d", "30d", "lifetime"], required=True)
    args = parser.parse_args()
    key = serialization.load_pem_private_key(Path(args.private_key).read_bytes(), password=None)
    now = datetime.now(timezone.utc).replace(microsecond=0)
    expires = None if args.duration == "lifetime" else now + timedelta(days=int(args.duration[:-1]))
    payload = {
        "product": PRODUCT,
        "licenseID": str(uuid.uuid4()),
        "issuedAt": now.isoformat().replace("+00:00", "Z"),
        "expiresAt": expires.isoformat().replace("+00:00", "Z") if expires else None,
    }
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    token = b64url(raw) + "." + b64url(key.sign(raw))
    print(token)

if __name__ == "__main__": main()
