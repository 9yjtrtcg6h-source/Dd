# Custom 3105 license keys

This is an **additional license system for this modified build only**. It does not validate or replace keys issued by the original 3105 developer.

## Generate a key

1. Keep `3105_custom_license_private_key.pem` in a safe location outside the app and source ZIP. Never distribute it.
2. Install Python 3 and the dependency: `python3 -m pip install cryptography`
3. From this `tools` folder, run one of:

   `python3 license_generator.py --private-key /path/to/3105_custom_license_private_key.pem --duration 1d`

   Supported durations: `1d`, `7d`, `30d`, `lifetime`.
4. Copy the printed token into Settings → License activation in the modified app.

The app contains only the Ed25519 public key. The private key is kept outside the app bundle. If you replace the keypair, update the public key in `ThreeOneOSFive/helpers/LicenseManager.swift` and rebuild the app.

## Important limitation

The new license status is displayed in Settings and keys are verified locally. Existing 3105 features are **not gated** by this patch. To restrict a specific feature, add an explicit `LicenseManager.shared.isLicensed` check at that feature's entry point after deciding which features should require a license. Offline expiry checks depend on the device clock and can be bypassed on a device the user controls; use a server for stronger enforcement.
