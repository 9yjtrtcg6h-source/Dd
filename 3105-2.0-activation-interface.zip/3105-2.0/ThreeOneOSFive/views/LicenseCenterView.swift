import SwiftUI

struct LicenseCenterView: View {
    @StateObject private var manager = LicenseManager.shared
    @State private var licenseText = ""
    @State private var alertMessage = ""
    @State private var showingAlert = false
    @FocusState private var keyFieldFocused: Bool

    private let panel = Color(red: 0.105, green: 0.105, blue: 0.115)
    private let accent = Color(red: 0.20, green: 0.78, blue: 0.59)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 22) {
                    Spacer(minLength: 52)

                    Text("🦊")
                        .font(.system(size: 112))
                        .accessibilityHidden(true)

                    Text("Activate 3105")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundStyle(.white)

                    Text("Paste a license key below to activate this modified build. Keys are verified using its configured signing key.")
                        .font(.system(size: 16))
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.gray)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 12)

                    VStack(alignment: .leading, spacing: 18) {
                        HStack {
                            Text("Activation key")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(.white)
                            Spacer()
                            if manager.isLicensed {
                                Label("Active", systemImage: "checkmark.seal.fill")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(accent)
                            }
                        }

                        TextField("Paste your key here", text: $licenseText, axis: .vertical)
                            .font(.system(size: 17, design: .monospaced))
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .lineLimit(1...3)
                            .focused($keyFieldFocused)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 15)
                            .foregroundStyle(.white)
                            .background(Color.black.opacity(0.22))
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        Button {
                            keyFieldFocused = false
                            if manager.activate(licenseText) {
                                licenseText = ""
                                alertMessage = manager.statusMessage
                            } else {
                                alertMessage = "This key is invalid, expired, or was issued for a different build."
                            }
                            showingAlert = true
                        } label: {
                            Text("Activate")
                                .font(.system(size: 17, weight: .semibold))
                                .frame(maxWidth: .infinity)
                                .frame(height: 64)
                                .foregroundStyle(.white.opacity(0.85))
                                .background(accent.opacity(licenseText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.28 : 0.82))
                                .clipShape(Capsule())
                        }
                        .disabled(licenseText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                        Button {
                            alertMessage = "Add your authorized 3105 purchase-page URL in LicenseCenterView.swift to enable this link."
                            showingAlert = true
                        } label: {
                            Label("Buy a key on the web", systemImage: "cart")
                                .font(.system(size: 17, weight: .semibold))
                                .frame(maxWidth: .infinity)
                                .frame(height: 64)
                                .foregroundStyle(accent)
                                .background(Color(red: 0.09, green: 0.29, blue: 0.23))
                                .clipShape(Capsule())
                        }

                        Button("Retry verification") {
                            manager.refresh()
                            alertMessage = manager.statusMessage
                            showingAlert = true
                        }
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(accent)
                        .padding(.top, 2)

                        Text(manager.statusMessage)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(22)
                    .background(panel)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    .padding(.horizontal, 18)

                    Spacer(minLength: 40)
                }
                .frame(maxWidth: 560)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
        .toolbar(.hidden, for: .navigationBar)
        .alert("3105 License", isPresented: $showingAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
        .onAppear { manager.refresh() }
    }
}
